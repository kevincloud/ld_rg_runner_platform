VERSION = "9.8.0" # x-release-please-version
